#include "MyFunc_Ptr.H"
#include <cmath>

double f(double x)
{
  return sqrt(x);
}
