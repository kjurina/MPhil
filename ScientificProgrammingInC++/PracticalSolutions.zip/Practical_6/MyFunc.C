#include "MyFunc.H"
#include <cmath>

double f(double x)
{
  return sqrt(x);
}
