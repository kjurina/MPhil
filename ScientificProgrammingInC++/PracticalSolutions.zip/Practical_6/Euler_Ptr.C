#include "Euler_Ptr.H"

double eulerStep(const std::function<double(double)>& f, double x, double dt)
{
  return x + f(x) * dt;
}
