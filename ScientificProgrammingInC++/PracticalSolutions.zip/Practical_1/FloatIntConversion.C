#include <iostream>

int main(void)
{
  float c = 1e34;
  std::cout << c << std::endl;
  int b = c;
  std::cout << b << std::endl;
  return 0;
}
